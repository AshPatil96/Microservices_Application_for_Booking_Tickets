package com.Booking.User.Service.ServiceDemo;




import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.Booking.User.Service.Entity.User;
import com.Booking.User.Service.Repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public User saveUser(User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepository.save(user);
    }

    public User findByUsername(String username) {
        return userRepository.findByUsername(username);
    }
}

