package com.Booking.User.Service.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.Booking.User.Service.Entity.User;
import com.Booking.User.Service.ServiceDemo.UserService;

@RestController
@RequestMapping("/users")
public class UserController {
	@Autowired
	private UserService userService;

	@PostMapping("/register")
	public User registerUser(@RequestBody User user) {
		return userService.saveUser(user);
	}

	@GetMapping("/{username}")
	public User getUser(@PathVariable String username) {
		return userService.findByUsername(username);
	}
}
