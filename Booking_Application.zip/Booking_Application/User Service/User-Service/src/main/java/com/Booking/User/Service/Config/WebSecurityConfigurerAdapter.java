package com.Booking.User.Service.Config;

public class WebSecurityConfigurerAdapter {

}
