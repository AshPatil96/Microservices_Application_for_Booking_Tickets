package com.Booking.Notification.Service.ServiceDemo;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
@Service
public class NotificationService {
	
	@Autowired
    private JavaMailSender javaMailSender;

    public void sendNotification(com.Booking.Notification.Service.Model.Notification notification) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(notification.getRecipient());
        message.setSubject("Booking Confirmation");
        message.setText(notification.getMessage());
        javaMailSender.send(message);
    }

}
