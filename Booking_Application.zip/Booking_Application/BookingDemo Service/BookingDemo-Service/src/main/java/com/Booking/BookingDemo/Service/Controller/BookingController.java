package com.Booking.BookingDemo.Service.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.Booking.BookingDemo.Service.Model.Booking;
import com.Booking.BookingDemo.Service.ServiceDemo.BookingService;

import java.util.List;

@RestController
@RequestMapping("/bookings")
public class BookingController {
	@Autowired
	private BookingService bookingService;

	@PostMapping
	public Booking createBooking(@RequestBody Booking booking) {
		return bookingService.saveBooking(booking);
	}

	@GetMapping
	public List<Booking> getAllBookings() {
		return bookingService.getAllBookings();
	}
}
