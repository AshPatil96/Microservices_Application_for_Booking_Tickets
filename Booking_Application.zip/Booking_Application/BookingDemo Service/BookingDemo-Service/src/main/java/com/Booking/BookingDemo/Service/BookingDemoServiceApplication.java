package com.Booking.BookingDemo.Service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookingDemoServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookingDemoServiceApplication.class, args);
	}

}
